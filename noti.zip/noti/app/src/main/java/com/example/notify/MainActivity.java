package com.example.notify;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.notify.R;

public class MainActivity extends AppCompatActivity {


    private static final String C_ID = "Notify me";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn = findViewById(R.id.but);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notification();
            }
        });
    }

    private void notification()
    {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification not;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            not = new Notification.Builder(this)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setAutoCancel(true)
                    .setContentText("New message")
                    .setSubText("New message from me")
                    .setChannelId(C_ID)
                    .build();
            nm.createNotificationChannel(new NotificationChannel(C_ID,"My Channel",NotificationManager.IMPORTANCE_HIGH));
        }
        else
        {
            not = new Notification.Builder(this)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setAutoCancel(true)
                    .setContentText("New message")
                    .setSubText("New message from me")
                    .setPriority(Notification.PRIORITY_DEFAULT)
                    .build();
        }
        nm.notify(0,not);
    }
}