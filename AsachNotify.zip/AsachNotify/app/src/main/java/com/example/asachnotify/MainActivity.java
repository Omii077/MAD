package com.example.asachnotify;

import androidx.annotation.DrawableRes;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button insert, update, delete, view, clear;
    EditText name, contact;

    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.editTextText);
        contact = findViewById(R.id.editTextNumber);

        insert = findViewById(R.id.button);
        update = findViewById(R.id.button2);
        delete = findViewById(R.id.button3);
        view = findViewById(R.id.button4);
        clear = findViewById(R.id.button5);

        db = openOrCreateDatabase("School", Context.MODE_PRIVATE,null);
        db.execSQL("create table if not exists data(name varchar,contact varchar);");

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(name.getText().toString().trim().isEmpty() || contact.getText().toString().trim().isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
               else
                {
                    db.execSQL("insert into data values('"+name.getText()+"','"+contact.getText()+"');");
                    Toast.makeText(MainActivity.this, "Data inserted", Toast.LENGTH_SHORT).show();
                }
               clearFiled();
            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name.getText().toString().trim().isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please enter value", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    db.execSQL("update data set contact='"+contact.getText()+"'");
                    Toast.makeText(MainActivity.this, "Updated", Toast.LENGTH_SHORT).show();
                }
                clearFiled();


            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name.getText().toString().trim().isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please enter value", Toast.LENGTH_SHORT).show();
                }
                Cursor c = db.rawQuery("select * from data where name='"+name.getText()+"';",null);
                if (c.moveToFirst())
                {
                    contact.setText(c.getString(1));
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Not folund", Toast.LENGTH_SHORT).show();
                }
                c.close();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (name.getText().toString().trim().isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please enter value", Toast.LENGTH_SHORT).show();
                }
               else
                {
                    db.execSQL("delete from data where name='"+name.getText()+"'");
                    Toast.makeText(MainActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
                }

                clearFiled();

            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearFiled();
            }
        });
    }
    private void clearFiled()
    {
        name.setText("");
        contact.setText("");
    }

}