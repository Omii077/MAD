package com.example.datapassing;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
 EditText sid,sname;
 Button pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sid=findViewById(R.id.first);
        sname=findViewById(R.id.last);
        pass=findViewById(R.id.btnpress);

        pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String studid=sid.getText().toString();
                String studname=sname.getText().toString();
                Intent changeactivity=new Intent(getApplicationContext(), MainActivity2.class);
                changeactivity.putExtra("Keyid",studid);
                changeactivity.putExtra("Keyname",studname);
                startActivity(changeactivity);
            }
        });

    }
}