package com.example.datapassing;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    private EditText t1,t2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        t1=findViewById(R.id.txt);
        t2=findViewById(R.id.txt1);
        String ssid=getIntent().getStringExtra("Keyid");
        String ssname=getIntent().getStringExtra("Keyname");
        t1.setText(ssid);
        t2.setText(ssname);
    }
}